/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.equipment.dao;

import com.equipment.model.Employee;
import java.util.List;
/**
 *
 * @author Brendan McGalliard
 *         b.mcgalliard.dev@outlook.com
 *         +1(517)575-5880
 */
public class EmployeeDAO
{
    public Employee getEmployeeByID(int id)
    {
        return null;
    }
    
    public boolean addEmployee(Employee employee) 
    {
        return false;
    }
    
    public boolean removeEmployee(int employeeID)
    {
        return false;
    }
    
    public List<Employee> getAllEmployees()
    {
        return null;
    }
}
