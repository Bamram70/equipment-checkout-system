/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.equipment.dao;

import com.equipment.model.CheckoutRecord;
import java.time.LocalDate;
import java.util.List;
/**
 *
 * @author Brendan McGalliard
 *         b.mcgalliard.dev@outlook.com
 *         +1(517)575-5880
 */
public class CheckoutDAO
{
    public boolean addCheckoutRecord(CheckoutRecord record)
    {
        return false;
    }
    
    public boolean updateReturnDate(int recordID, LocalDate returnDate)
    {
        return false;
    }
    
    public List<CheckoutRecord> getAllCheckoutRecords()
    {
        return null;
    }
}
